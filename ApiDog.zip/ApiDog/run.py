# -*- coding: utf-8 -*-
import os
import datetime
from time import sleep


os.system('python manage.py runserver 0.0.0.0:8001')
#创建项目
##c:\python3\python.exe  C:\Python3\Scripts\django-admin.exe startproject ApiDog
#创建APP
##python manage.py startapp apptest

#-coding:UTF8-*-
# import os
# command ="ver" 
# os.system('python manage.py runserver 8081'.encode('utf-8'))
# os.system('python manage.py startapp books'.encode('utf-8'))

# os.system('python manage.py check'.encode('utf-8'))
#  
# os.system('python manage.py makemigrations'.encode('utf-8'))
# os.system('python manage.py migrate'.encode('utf-8'))
# os.system('python manage.py makemigrations books'.encode('utf-8'))
# os.system('python manage.py migrate books'.encode('utf-8'))

'''
һ���㴴����ģ�ͣ�Django�Զ�Ϊ��Щģ���ṩ�˸߼���Python API�� ���� python manage.py shell ������������������Կ���

'''
# os.system('python manage.py shell'.encode('utf-8'))

# os.system('python manage.py createsuperuser'.encode('utf-8'))
# os.system('python manage.py collectstatic'.encode('utf-8'))


#����sql���    for BAE   
# os.system('python manage.py sqlmigrate books 0001_initial'.encode('utf-8'))


