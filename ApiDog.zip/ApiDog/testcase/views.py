from django.shortcuts import render
from testcase.models import case,project
import time

#/caseList/页面
def caseList(request):
    templateHtml = 'caselist.html'
    caseObj = case.objects.exclude(deleted=1).order_by('-id')
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    form_commitProjectId = 0
    projectName = "所有项目"
    if request.POST:
        if ('Inquiry') in request.POST: #py3 
            form_commitProjectId = request.POST['projectId'].strip()
            templateHtml = 'caselist.html'
            if int(form_commitProjectId)>0:
                caseObj = case.objects.filter(projectId=form_commitProjectId,deleted=0).order_by('-id')
                projectName = project.objects.filter(id=form_commitProjectId).first().projectName
            else:
                caseObj = case.objects.exclude(deleted=1).order_by('-id')
                projectName = "所有项目"
        if ('delCase') in request.POST: #py3 
            form_commit = request.POST['caseid'].strip()
            templateHtml = 'caselist.html'
            if form_commit:
                case.objects.filter(id=form_commit).update(deleted=1)

    return render(request, templateHtml,{"caseObj":caseObj,
                                         "projectObj":projectObj,
                                         "form_commitProjectId":form_commitProjectId,
                                         "projectName":projectName
                                                })

#/addcase/页面
def addCase(request):
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    #给默认值
    projectId =  ''
    qname = ''
    qmethod =  ''
    qpath =  ''
    qmust =  ''
    qheader =  ''
    qbody =  ''
    qvalidate =  ''
    qextract =  ''
    msg = ''
 
    if request.POST:
        #获取前端传进来的值
        projectId =  request.POST['projectId']
        qname =  request.POST['qname']
        qmethod =  request.POST['qmethod']
        qpath =  request.POST['qpath']
        qmust =  request.POST['qmust']
        qheader =  request.POST['qheader']
        qbody =  request.POST['qbody']
        qvalidate =  request.POST['qvalidate'] #断言
        qextract =  request.POST['qextract'] #提取正则
        if (projectId !='' and qmethod !='' and qpath !='' and qmust !='' ): #判断必填字段不为空 and qbody !=''
            projectIdObj = project.objects.filter(id=projectId).first()
            if qname == '': #若不填写默认名称为“请求路径”名称"
                qname = qpath
            p = case(projectId =  projectId,
                    caseName = qname,
                    projectName=projectIdObj.projectName,
                    must = qmust,
                    headers = qheader,
                    body = qbody,
                    method = qmethod,
                    path = qpath,
                    validate = qvalidate,
                    extract = qextract,
                                )
            p.save()
        else:
            msg = '检查填写是否完善'
 
    return render(request, 'add_case.html',{"projectObj":projectObj,
                                            "projectId":projectId,
                                            "qname":qname,
                                            "qmethod":qmethod,
                                            "qpath":qpath,
                                            "qmust":qmust,
                                            "qheader":qheader,
                                            "qbody":qbody,
                                            "qvalidate":qvalidate,
                                            "qextract":qextract,
                                            "msg":msg,
                                     
                                                })
    
#/editcase/页面
def editCase(request,id):
    #用例列表进入编辑页面
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    editCaseObj = case.objects.get(id=int(id))

    #编辑保存用例
    ##给默认值
    projectId =  ''
    qname = ''
    qmethod =  ''
    qpath =  ''
    qmust =  ''
    qheader =  ''
    qbody =  ''
    qvalidate =  ''
    qextract =  ''
    msg = ''
 
    if request.POST:
        #获取前端传进来的值
        projectId =  request.POST['projectId']
        qname =  request.POST['qname']
        qmethod =  request.POST['qmethod']
        qpath =  request.POST['qpath']
        qmust =  request.POST['qmust']
        qheader =  request.POST['qheader']
        qbody =  request.POST['qbody']
        qvalidate =  request.POST['qvalidate'] #断言
        qextract =  request.POST['qextract'] #提取正则
        if (projectId !='' and qmethod !='' and qpath !='' and qmust !=''): #判断必填字段不为空  and qbody !=''
            projectIdObj = project.objects.filter(id=projectId).first()
            if qname == '': #若不填写默认名称为“请求路径”名称"
                qname = qpath
            case.objects.filter(id=id).update(projectId =  projectId,
                    caseName = qname,
                    projectName=projectIdObj.projectName,
                    must = qmust,
                    headers = qheader,
                    body = qbody,
                    method = qmethod,
                    path = qpath,
                    validate = qvalidate,
                    extract = qextract,
                    updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                )
            editCaseObj = case.objects.filter(id=id).first() #更新后，重新为editCaseObj赋数据库中的最新值
            msg = '更新成功'
        elif (projectId !='' or qmethod !='' or qpath !='' or qmust !='' or qbody !=''): #判断必填字段不为空
            msg = '检查填写是否完善'
        else:
            msg = '检查填写是否完善'
            
    return render(request, 'edit_case.html', {
                                            'editCaseObj':editCaseObj,
                                            'projectObj':projectObj,
                                            'msg':msg,
                                            })
    
