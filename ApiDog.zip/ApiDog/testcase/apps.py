from django.apps import AppConfig


class TestcaseConfig(AppConfig):
    name = 'testcase'
