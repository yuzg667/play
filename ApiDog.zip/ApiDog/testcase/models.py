# -*- coding: utf-8 -*-
from django.db import models

import jsonfield
# Create your models here.
class case(models.Model):
    projectName =  models.CharField('项目名称',blank=True,null=True,max_length=30)
    projectId =  models.IntegerField('所属项目ID',blank=True,null=True,)
    caseName = models.CharField('用例名称',blank=True,null=True,max_length=30)
    caseModule = models.CharField('用例所属模块',blank=True,null=True,max_length=30,default='0')
    must = models.IntegerField('是否必须执行，0否，1是',blank=True,null=True,default='0')
    relyCaseIdList = models.CharField('依赖的case，如登录',blank=True,null=True,max_length=30,default='0')
    headers = models.CharField('请求头',max_length=255,null=True)
    body = models.TextField('请求body',blank=True,null=False,)
    method = models.CharField('请求方法',blank=True,null=True,max_length=30)
    path = models.CharField('接口路径',max_length=255,blank=True,null=False)
    validate = models.TextField('断言',blank=True,null=False)
    extract = models.TextField('设置的提取值表达式',blank=True,null=False)
    deleted = models.IntegerField('是否删除',blank=True,default='0',null=True)
    createTime = models.DateTimeField('创建时间',auto_now_add=True)
    updateTime = models.DateTimeField(auto_now=True, verbose_name='更新时间')

class project(models.Model):
    projectName =  models.CharField('项目名称',max_length=20)
    baseURL = models.CharField('请求接口域名',max_length=255)
    defaultHeaders = models.TextField('默认请求头')
    defaultValidate = models.TextField('默认断言',blank=True,null=True)
    deleted = models.IntegerField('是否删除',default='0')
    createTime = models.DateTimeField('创建时间',auto_now_add=True)
    updateTime = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    class Meta:
        verbose_name = '项目'
        verbose_name_plural = '项目'