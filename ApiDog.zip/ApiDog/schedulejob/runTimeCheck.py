'''
判断执行时间是否已到，如已到执行时间，更改状态status为3待执行
'''
from schedulejob.models import jobs
import time
import datetime

def monthRun(jobid):
    jobObj = jobs.objects.filter(id=jobid).first()
    day = jobObj.runStyle.split("-")[1]
    runtime = jobObj.RunTime
    lastRuntime = jobObj.lastRuntime
    status = jobObj.status
#     status = 1
#     runtime = "03:04:00.000000"
#     day = "22"
    currentYearMonth = time.strftime("%Y-%m")
    runday = currentYearMonth + '-' + day
    nextRuntime = str(runday)  + ' ' + str(runtime)
    nextRuntime = datetime.datetime.strptime(nextRuntime[:19], '%Y-%m-%d %H:%M:%S')
    currentTime = datetime.datetime.strptime(time.strftime("%Y-%m-%d %H:%M:%S"), '%Y-%m-%d %H:%M:%S') #datetime.datetime.strptime('2015-03-02 17:41:20', '%Y-%m-%d %H:%M:%S')
    currentDayTime = time.strftime("%Y-%m-%d") + ' ' + '00:00:00'
    currentDayTime = datetime.datetime.strptime(currentDayTime, '%Y-%m-%d %H:%M:%S')
    lastRuntime = datetime.datetime.strptime(str(lastRuntime)[:19], '%Y-%m-%d %H:%M:%S')
    
    if nextRuntime<=currentTime and (status == 1 or status==5) and currentDayTime>lastRuntime: #判断到了执行时间，而且status=1启用
        print(f"更新[月任务]id{jobid}为状态3待执行")
        jobs.objects.filter(id=jobid).update(
                                                         status=3,
                                                         lastRuntime = time.strftime("%Y-%m-%d %H:%M:%S"),
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
    
    else:
        print(f"\n暂无已到达执行时间的[月任务]")
    
def weekRun(jobid):
    jobObj = jobs.objects.filter(id=jobid).first()
    day = jobObj.runStyle.split("-")[1]
    runtime = jobObj.RunTime
    lastRuntime = jobObj.lastRuntime
    status = jobObj.status
    currentYearMonth = time.strftime("%Y-%m-%d")
    nextRuntime = str(currentYearMonth)  + ' ' + str(runtime)
    currentDayWeek = datetime.datetime.now().weekday()+1 #当天周几
    nextRuntime = datetime.datetime.strptime(nextRuntime[:19], '%Y-%m-%d %H:%M:%S')
    currentTime = datetime.datetime.strptime(time.strftime("%Y-%m-%d %H:%M:%S"), '%Y-%m-%d %H:%M:%S') #datetime.datetime.strptime('2015-03-02 17:41:20', '%Y-%m-%d %H:%M:%S')
    currentDayTime = time.strftime("%Y-%m-%d") + ' ' + '00:00:00'
    currentDayTime = datetime.datetime.strptime(currentDayTime, '%Y-%m-%d %H:%M:%S')
    lastRuntime = datetime.datetime.strptime(str(lastRuntime)[:19], '%Y-%m-%d %H:%M:%S')

    if nextRuntime<=currentTime and str(currentDayWeek)==str(day) and (status == 1 or status==5) and currentDayTime>lastRuntime: #判断到了执行时间，而且status=1启用
        print(f"更新[周任务]id{jobid}为状态3待执行")
        jobs.objects.filter(id=jobid).update(
                                                         status=3,
                                                         lastRuntime = time.strftime("%Y-%m-%d %H:%M:%S"),
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
    else:
        print(f"\n暂无已到达执行时间的[周任务]")
        
        
def dayRun(jobid):
    jobObj = jobs.objects.filter(id=jobid).first()
    runtime = jobObj.RunTime
    lastRuntime = jobObj.lastRuntime
    status = jobObj.status
    currentYearMonth = time.strftime("%Y-%m-%d")
    nextRuntime = str(currentYearMonth)  + ' ' + str(runtime)
    nextRuntime = datetime.datetime.strptime(nextRuntime[:19], '%Y-%m-%d %H:%M:%S')
    currentTime = datetime.datetime.strptime(time.strftime("%Y-%m-%d %H:%M:%S"), '%Y-%m-%d %H:%M:%S') #datetime.datetime.strptime('2015-03-02 17:41:20', '%Y-%m-%d %H:%M:%S')
    currentDayTime = time.strftime("%Y-%m-%d") + ' ' + '00:00:00'
    currentDayTime = datetime.datetime.strptime(currentDayTime, '%Y-%m-%d %H:%M:%S')
    lastRuntime = datetime.datetime.strptime(str(lastRuntime)[:19], '%Y-%m-%d %H:%M:%S')

    if nextRuntime<=currentTime and (status == 1 or status==5) and currentDayTime>lastRuntime: #判断到了执行时间，而且status=1启用
        print(f"更新[日任务]id{jobid}为状态3待执行")
        jobs.objects.filter(id=jobid).update(
                                                         status=3,
                                                         lastRuntime = time.strftime("%Y-%m-%d %H:%M:%S"),
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
    else:
        print(f"\n暂无已到达执行时间的[日任务]")