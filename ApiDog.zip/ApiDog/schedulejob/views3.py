from django.shortcuts import render
from testcase.models import case,project
from runcase.models import caseSet,runHistory
from schedulejob.models import jobs
import time
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore, register_events, register_job
import threading



# scheduler.add_jobstore(DjangoJobStore(), 'djangojobstore')
# Create your views here.
def schedulejoblist(request):
#     scheduler = BackgroundScheduler()
#     jobsss = scheduler.get_jobs()
#     print(jobsss)
#     scheduler.add_jobstore(DjangoJobStore(), "default")
    
    jobsObj = jobs.objects.exclude(deleted=1).order_by('-id')
    if request.POST:
        scheduler = BackgroundScheduler()
        jobsss = scheduler.get_jobs()
        print(jobsss)
        scheduler.add_jobstore(DjangoJobStore(), "default")
        jobid = request.POST['jobid'].strip()
        
        if ('openjob') in request.POST:
            jobs.objects.filter(id=jobid).update(status=1,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
            ##https://note.youdao.com/web/#/file/recent/note/wcp1566782277036579/  详解django-apscheduler的使用方法 - 掘金
            #开启定时工作
#             try:
            if 1==1:
                jobObj = jobs.objects.filter(id=jobid).first()
                if jobObj.runStyle=='date':
                    jobname=str(jobid) + '-' + str(time.strftime('%Y%m%d%H%M%S'))
#                     scheduler = BackgroundScheduler()
#                     scheduler.add_jobstore(DjangoJobStore(), "default")
#                     scheduler.add_job(my_job,"interval",seconds=5,args=[jobid],id=jobid)
                    LOC = jobObj.expression #把表达式的txt转换为code执行
                    exec(LOC) 
                    jobs.objects.filter(id=jobid).update(
                                                         scheduleName=jobname,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )

                if jobObj.runStyle=='cron':
                    jobname=str(jobid) + '-' + str(time.strftime('%Y%m%d%H%M%S'))
#                     scheduler = BackgroundScheduler()
#                     scheduler.add_jobstore(DjangoJobStore(), "default")
#                     scheduler.add_job(my_job,'cron', hour=15, minute=54,args=[jobid], id=jobid)
                    LOC = jobObj.expression #把表达式的txt转换为code执行
                    exec(LOC) 
#                     threads=threading.Thread(target=run,args=(host, name, password, workDir))  # https://www.jianshu.com/p/3b164cef76b8
                    jobs.objects.filter(id=jobid).update(
                                                        scheduleName=jobname,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
                if jobObj.runStyle=='interval':
                    jobname=str(jobid) + '-' + str(time.strftime('%Y%m%d%H%M%S'))
#                     scheduler = BackgroundScheduler()
#                     scheduler.add_jobstore(DjangoJobStore(), "default")
                    LOC = jobObj.expression #把表达式的txt转换为code执行
                    exec(LOC) 
                    jobsss = scheduler.get_jobs()
                    print(jobsss)
                    jobs.objects.filter(id=jobid).update(
                                                        scheduleName=jobname,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
#                     threads=threading.Thread(target=exec,args=(LOC))
#                     threads.start()
                    
                register_events(scheduler)
                scheduler.start() #使用下边的多线程，这样就不会冲突了。不然会导致：同时开启多个任务，前一个任务不执行。
#                 threads=threading.Thread(target=scheduler.start())
#                 threads.start()
                
                
#             except Exception as e:
#                 print(e)
#                 # 有错误就停止定时器
#                 scheduler.pause()     
                
        if ('pausejob') in request.POST:
#             scheduler = BackgroundScheduler()
#             scheduler.add_jobstore(DjangoJobStore(), "default")
            jobid = request.POST['jobid'].strip()
#             jobname=str(jobid) + '-' + str(time.strftime('%Y%m%d%H%M%S'))
            jobname = jobs.objects.filter(id=jobid).first().scheduleName
            scheduler.remove_job(jobname)
#             scheduler.pause()
#             scheduler.pause_job(jobname)
            jobs.objects.filter(id=jobid).update(status=2,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                              )
    return render(request, 'schedulejoblist.html',{
                                                'jobsObj':jobsObj,
                                    
                                                })
def my_job(jobid):
#     requestPost.runRequestPost()
    print('9999999999999')
def my_job2(jobid):
#     requestPost.runRequestPost()
    print('8888')
# register_events(scheduler)
# scheduler.start()

def myjob():
    # 这里写你要执行的任务
    print('一次性任务')
    print("\n定时任务检查："+ str(time.strftime("%Y-%m-%d %H:%M:%S")))
    caseSetID = jobs.objects.filter(id=jobid).first().caseSetid
    caseSetObj = caseSet.objects.filter(id=caseSetID).order_by('updateTime').first() #取出status=1的待执行的caseSet
    print("取到的caseSet:" + str(caseSetObj))
    if (str(caseSetObj) !="None") and (str(caseSetObj).isspace() == False) and (len(str(caseSetObj)) != 0):
        caseSetId = caseSetObj.id
        submitCaseidlist = caseSetObj.caseIdList
        #状态更新为2运行中
        caseSet.objects.filter(id=caseSetId).update(status=2,
                                                   updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                       )
        #执行caseSet
        requestPost.runRequestPost(submitCaseidlist,caseSetId)
        oldRunNum = caseSet.objects.get(id=int(caseSetId)).runNum
        newRunNum = oldRunNum + 1
        #状态更新为3运行结束
        caseSet.objects.filter(id=caseSetId).update(status=3,
                                                    runNum=newRunNum,
                                                   updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                       )
    else:
        print("暂无需要执行的caseSet")
                        
def addschedulejob(request):
#     requestPost.runRequestPost()
    print('9999999999999')
    return render(request, 'schedulejoblist.html',{
                                    
                                                })
   
def editschedulejob(request):
#     requestPost.runRequestPost()
    
    return render(request, 'schedulejoblist.html',{
                                    
                                                })
    
def jobp2(request):
    caseSetObj = caseSet.objects.exclude(deleted=1).order_by('id')
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    caseidlist = ''
    form_commitProjectId = 0
    projectName = "所有项目"
    if request.method == "GET":
        return render(request,"jobp2.html",{
                            "caseid":caseidlist,
                                         "caseSetObj":caseSetObj,
                                         "projectObj":projectObj,
                                         "form_commitProjectId":form_commitProjectId,
                                         "projectName":projectName
                         })
    
    elif request.POST:
#         city =request.POST.get("city")
        #添加用例
        if ('addcase2set') in request.POST: #py3 
            check_box_list = request.POST.get("check_box_list")  #request.POST.getlist("check_box_list")
            print(caseidlist)
#             check_box_list_str = str(check_box_list).replace(' ', '').replace("'", "\"").replace("\"", "")#去除空格、引号换双引号、去掉双引号
# #             print(check_box_list_str)
# #             check_box_list = json.loads(check_box_list_str)
#             caseidlist = check_box_list_str
#             print(caseidlist)
        if ('Inquiry') in request.POST: #py3 
            form_commitProjectId = request.POST['projectId'].strip()
            templateHtml = 'caselist.html'
            if int(form_commitProjectId)>0:
                caseSetObj = caseSet.objects.filter(projectId=form_commitProjectId,deleted=0).order_by('-id')
                projectName = project.objects.filter(id=form_commitProjectId).first().projectName
            else:
                caseSetObj = caseSet.objects.exclude(deleted=1).order_by('id')
                projectName = "所有项目"
        return render(request,"jobp2.html",{"caseid":caseidlist,
                                         "caseSetObj":caseSetObj,
                                         "projectObj":projectObj,
                                         "form_commitProjectId":form_commitProjectId,
                                         "projectName":projectName
                                         })