'''
删除django_apscheduler_djangojobexecution表中十分钟前的记录
'''
# -*- coding:utf-8 -*-
import pymysql.cursors
import pymysql
import time
from django.conf import settings
import configparser


def pymysql_delete():
    conf_path = settings.CONF_DIR  #"E:/pythonAPItest/ApiDog/configs/conf.txt"
    cf = configparser.ConfigParser()
    cf.read(conf_path,encoding="utf-8")
    
    db_NAME = cf.get("db", "NAME")  # 读取配置文件
    db_USER = cf.get("db", "USER")  
    db_PASSWORD = cf.get("db", "PASSWORD") 
    db_HOST = cf.get("db", "HOST") 
    db_PORT = cf.get("db", "PORT")  
    conn = pymysql.connect(user=db_USER, passwd=db_PASSWORD,
                           host=db_HOST, db=db_NAME,charset='utf8')
    cur = conn.cursor()
    sql = "DELETE FROM `django_apscheduler_djangojobexecution` WHERE run_time <= (date_add(NOW(), interval -60 second));"
    print("\n########################################")
    sta=cur.execute(sql)
#     print("sta"+str(sta))
    if sta==1:
        print ("\n删除job表中一分钟前的记录完毕 -- "+ str(time.strftime("%Y-%m-%d %H:%M:%S")))
    else:
        print ("\n未发现需要删除的记录 -- "+ str(time.strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    cur.close()    
    conn.close()



