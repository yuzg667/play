from django.shortcuts import render
from testcase.models import case,project
from runcase.models import caseSet,runHistory
from schedulejob.models import jobs
import time
import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore, register_events, register_job
from schedulejob.runTimeCheck import monthRun
from schedulejob.getJob import getJobStatus1,getJobStatus3
from schedulejob.delJobRecord import pymysql_delete


def schedulejoblist(request):
    jobsObj = jobs.objects.exclude(deleted=1).order_by('-id')
    if request.POST:
        scheduler = BackgroundScheduler()
        jobsss = scheduler.get_jobs()
        print(jobsss)
        scheduler.add_jobstore(DjangoJobStore(), "default")
        jobid = request.POST['jobid'].strip()
        
        if ('openjob') in request.POST:
            jobs.objects.filter(id=jobid).update(status=1,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )

                
        if ('pausejob') in request.POST:
            jobs.objects.filter(id=jobid).update(status=2,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                              )
    return render(request, 'schedulejoblist.html',{
                                                'jobsObj':jobsObj,
                                                'defaultDate':datetime.datetime.strptime("2000-09-20 15:57:20", '%Y-%m-%d %H:%M:%S')
                                                })

                        
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore, register_events, register_job
##https://note.youdao.com/web/#/file/recent/note/wcp1566782277036579/  详解django-apscheduler的使用方法 - 掘金
#开启定时工作
try:
    # 实例化调度器
    scheduler = BackgroundScheduler()
    # 调度器使用DjangoJobStore()
    scheduler.add_jobstore(DjangoJobStore(), "default")
    # 设置定时任务，选择方式为interval，时间间隔为10s
    # 另一种方式为每天固定时间执行任务，对应代码为：
    # @register_job(scheduler, 'cron', day_of_week='mon-fri', hour='9', minute='30', second='10',id='task_time')
    @register_job(scheduler,"interval", seconds=60) # minutes=10 seconds=5
    def my_job():
        # 这里写你要执行的任务
        print("\n-----------------------------------------")
        print("\n定时任务2检查："+ str(time.strftime("%Y-%m-%d %H:%M:%S")))

        getJobStatus1()
        getJobStatus3()
        pymysql_delete() # 删除django_apscheduler_djangojobexecution表中十分钟前的记录
        
    register_events(scheduler)
    scheduler.start()
     
except Exception as e:
    print(e)
    # 有错误就停止定时器
    scheduler.shutdown()    

