from django.contrib import admin

# Register your models here.
# Register your models here.
from schedulejob.models import jobs
# from models import jmxRun,jmxFile

class jobsAdmin(admin.ModelAdmin):
    list_display = ('jobName','caseSetid','id','runStyle','status')
    search_fields = ('jobName','caseSetid','id','expression')

admin.site.register(jobs,jobsAdmin)
