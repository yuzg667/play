from django.apps import AppConfig


class SchedulejobConfig(AppConfig):
    name = 'schedulejob'
