from django.db import models
from runcase.models import caseSet
from celery.worker.strategy import default
import datetime

caseSetObj = caseSet.objects.filter(deleted=0).order_by('-id')
# Create your models here.
class jobs(models.Model): #用例集 - 可以当做模块，也可以把需要执行的用例加进来
    jobName =  models.CharField('任务名称',null=True,max_length=30)
    scheduleName =  models.CharField('定时任务id名称',null=True,max_length=30)
    caseSetid_choices=[(tag.id, str(tag.id)+'/'+tag.caseSetName) for tag in caseSetObj]
    caseSetid = models.IntegerField('用例集ID/名称',null=True,choices=caseSetid_choices)
#     caseSetName =  models.CharField('用例集名称',null=True,max_length=30)
    runStyle_CHOICES = (    ('day','每天'),
                            ('week-1','每周一'),
                            ('week-2','每周二'),
                            ('week-3','每周三'),
                            ('week-4','每周四'),
                            ('week-5','每周五'),
                            ('week-6','每周六'),
                            ('week-7','每周日'),
                            ('month-01','每月1号'),
                            ('month-02','每月2号'),
                            ('month-03','每月3号'),
                            ('month-04','每月4号'),
                            ('month-05','每月5号'),
                            ('month-06','每月6号'),
                            ('month-07','每月7号'),
                            ('month-08','每月8号'),
                            ('month-09','每月9号'),
                            ('month-10','每月10号'),
                            ('month-11','每月11号'),
                            ('month-12','每月12号'),
                            ('month-13','每月13号'),
                            ('month-14','每月14号'),
                            ('month-15','每月15号'),
                            ('month-16','每月16号'),
                            ('month-17','每月17号'),
                            ('month-18','每月18号'),
                            ('month-19','每月19号'),
                            ('month-20','每月20号'),
                            ('month-21','每月21号'),
                            ('month-22','每月22号'),
                            ('month-23','每月23号'),
                            ('month-24','每月24号'),
                            ('month-25','每月25号'),
                            ('month-26','每月26号'),
                            ('month-27','每月27号'),
                            ('month-28','每月28号')
                        )
    runStyle =  models.CharField('类型',max_length=20,null=True,choices=runStyle_CHOICES)
#     datetimeOrInterval = models.IntegerField('执行间隔',null=True)
    RunTime = models.TimeField(null=True,verbose_name='执行时间')
#     expression =  models.CharField('表达式',null=True,max_length=100)
#     projectName =  models.CharField('所属项目名称',null=True,max_length=30)
#     projectId =  models.IntegerField('所属项目ID',null=True)
    status = models.IntegerField('运行状态',null=True,default='0',choices=((0,'0默认'),(0,'1启用'),(2,'2暂停'),(3,'3待执行'),(4,'4定时任务执行中'),(5,'5任务运行结束')))
    deleted = models.IntegerField('是否删除',default='0',null=True,choices=((0,'0默认'),(1,'1删除')))
    lastRuntime = models.DateTimeField(verbose_name='上次执行时间',default=datetime.datetime.strptime("2000-09-20 15:57:20", '%Y-%m-%d %H:%M:%S'))
    createTime = models.DateTimeField('创建时间',auto_now_add=True)
    updateTime = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    def __unicode__(self):
            return self.title;
    class Meta:
        verbose_name = '定时任务'
        verbose_name_plural = '定时任务'