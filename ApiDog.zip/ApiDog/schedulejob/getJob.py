'''
判断执行时间是否已到，如已到执行时间，更改状态status为3待执行
'''
from testcase.models import case,project
from runcase.models import caseSet,runHistory
from schedulejob.models import jobs
from runcase.requestMethod import requestGet,requestPost
from schedulejob.runTimeCheck import monthRun,weekRun,dayRun
from sendnotice.views import sendDingding,sendEmail
import time
from django.db.models import Q

def getJobStatus1():
        #找已经到达执行时间的job，把状态置为3
        jobsObj = jobs.objects.filter(Q(status=1) | Q(status=5)).order_by('updateTime') #取出status=1或5的list
#         print("取到的任务:" + str(jobsObj))
        if len(jobsObj) >0:
            for job in jobsObj:
                jobid = job.id
#                 print(f"\n已到达执行时间的jobID:{jobid}")
#                 print(jobid)
                if job.runStyle.split("-")[0]=='month':
                    monthRun(jobid)
                if job.runStyle.split("-")[0]=='week':
                    weekRun(jobid)
                if job.runStyle.split("-")[0]=='day':
                    dayRun(jobid)
        else:
            print(f"\n暂无已到达执行时间的job")
            
def getJobStatus3():
        #找状态为3的job，并执行
        jobsObjWaitRun = jobs.objects.filter(status=3).order_by('updateTime') #取出status=1的待执行的list
        if len(jobsObjWaitRun)>0:
            for job in jobsObjWaitRun:
#                             jobid = job.id
                caseSetId = job.caseSetid
                caseSetObj = caseSet.objects.filter(id=caseSetId).order_by('updateTime').first()
                submitCaseidlist = caseSetObj.caseIdList
                #状态更新为2运行中
                caseSet.objects.filter(id=caseSetId).update(status=2,#2运行中，3运行结束
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
                jobs.objects.filter(id=caseSetId).update(status=4, #执行中
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
                #执行caseSet
                runId = requestPost.runRequestPost(submitCaseidlist,caseSetId)
                print(runId)
                oldRunNum = caseSet.objects.get(id=int(caseSetId)).runNum
                newRunNum = oldRunNum + 1
                #状态更新为3运行结束
                caseSet.objects.filter(id=caseSetId).update(status=3, #2运行中，3运行结束
                                                            runNum=newRunNum,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
                jobs.objects.filter(id=job.id).update(status=5, #执行结束
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
                
                jobName=job.jobName
                jobId=job.id
                runId=runId
                caseSetId=caseSetId
                sendDingding(jobName,jobId,runId,caseSetId)
                sendEmail(jobName,jobId,runId,caseSetId)
        else:
            print("\n暂无需要待执行status=3的job")