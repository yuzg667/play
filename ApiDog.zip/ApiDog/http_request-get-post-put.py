
# -*- coding: utf-8 -*-
import urllib    
import re
import time
import  sys,  httplib
import os
from datetime import datetime,timedelta
	
def http_request():
    params  = "token=1a62232fc4ba81db6f728ca7f009ab67&mobile=18733336666&code="+ str(code_format)
    print (params)
    headers  =  {
            'Host': 'api.test.hooclub.com',
			'Content-Length': '67',
			'Pragma': 'no-cache',
			'Cache-Control': 'no-cache',
			'Accept': 'application/json, text/javascript, */*; q=0.01',
			'Origin': 'http://wap.test.hooclub.com',
			'User-Agent': 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Mobile Safari/537.36',
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'Referer': 'http://wap.test.hooclub.com/set/mobile?inviteCode=20',
			'Accept-Encoding': 'gzip, deflate, sdch',
			'Accept-Language': 'zh-CN,zh;q=0.8',
			'Connection': 'close'
    }   
    con2  =  httplib.HTTPConnection("api.test.hooclub.com:80")
    con2.request("PUT", "/h5/user",params,  headers)
    r2  =  con2.getresponse()
    print (r2.status)
    if  r2.status  ==  200:
            print  ("Success",  "\n")
            html = r2.read()
            #print html
            con2.close()
    else:
            print  ("Failed",  "\n")
            con2.close()
			
def code():
	code = 0000
	while code<9999:
		code = code+1
		global code_format
		code_format = '%04d' %code # '%04d' ：四个0
		http_request()
code()		
			
# if __name__ == '__main__':
    # http_request()
	
	

             
