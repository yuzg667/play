# -*- coding: utf-8 -*-
import os
import datetime

ssss = ''
print(len(ssss))
print(str(ssss).isspace())
if ssss.isspace() == False:
    print('无空格')
elif ssss.isspace() == True:
    print('有空格')
    
    
import json

sslist="[1 , 2, 3]"
print(type(sslist))
listst = json.loads(sslist)
print(type(listst))
for i in listst:
    print(i)

print(len(listst))


import time
print (time.strftime('%Y%m%d%H%M%S'))

year = 2019  #int
day = "04.10"  #str
newStr = f"Today is {year} {day}"
print(newStr)
newStr = F"Today is {year} {day}"
print(newStr)

path1 = "/mall/buy?token={token}&time={time}"
login_token = 'qwewqaxsaasdsadasda'
time=time.time()
path123 = path1.format(token=login_token,time=time)
print(path123)

lll = [1,2,3]
lll.remove(1)
print(lll)

import time
#2019-08-14 09:03:42.625407
print (time.strftime("%Y-%m-%d %H:%M:%S"))

strlist = "[['23','22'],['22']]"
print(strlist)

lists = json.loads(strlist.replace("'", "\""))
print(type(lists))
print(lists)
res_list=[]
for list in lists:
    res_list.extend(list)
    print(list)
print(res_list)
res_list2 = []
for i in res_list:
    if i not in res_list2:
        res_list2.append(i)
print(res_list2)


time1 = "1:20:03.017493"
print(time1[-6:] ) #毫秒
print(time1[-9:-7]) #秒
print(time1[-12:-10]) #分
print(time1[:-13]) #时


import requests
url="http://www.baidu.com/"
r = requests.get(url,timeout=10)
elapsed = "1:00:03.017493" # str(r.elapsed)
print(elapsed)
time2 = int(elapsed[:-13])*60*60*1000000 + int(elapsed[-12:-10])*60*1000000 + int(elapsed[-9:-7])*1000000 + int(elapsed[-6:])
print(time2)
