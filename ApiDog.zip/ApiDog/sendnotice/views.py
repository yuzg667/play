from django.shortcuts import render
from dingtalkchatbot.chatbot import DingtalkChatbot
from django.conf import settings
import configparser
from runcase.models import runHistory
from django.db.models import Sum,Count,Max,Min,Avg
from sendnotice.sent_email import MyEmail
import json


conf_path = settings.CONF_DIR  #"E:/pythonAPItest/ApiDog/configs/conf.txt"
cf = configparser.ConfigParser()
cf.read(conf_path,encoding="utf-8")
Host = cf.get("sendnotice", "Host")  # 读取配置文件

# Create your views here.
def sendDingding(jobName,jobId,runId,caseSetId):
    webhook = cf.get("sendnotice", "webhook")
    xiaoding = DingtalkChatbot(webhook)
    caseTotalNum = runHistory.objects.filter(runId=runId).aggregate(Count('id'))
    caseTotalNum = caseTotalNum['id__count'] 
    resultSuccess = runHistory.objects.filter(runId=runId,validateStatus=1).aggregate(Count('id'))
    resultSuccess = resultSuccess['id__count']
    resultFailed = runHistory.objects.filter(runId=runId,validateStatus=2).aggregate(Count('id'))
    resultFailed = resultFailed['id__count']
    result200 = runHistory.objects.filter(runId=runId,validateStatus=3).aggregate(Count('id'))
    result200 = result200['id__count']
    unkownError = runHistory.objects.filter(runId=runId).exclude(validateStatus__in=[1,2,3]).aggregate(Count('id'))
    unkownError = unkownError['id__count']
    resultSuccessTotal = resultSuccess + result200
    msg1 = f'''[测试结果推送-{resultFailed}失败]\n任务ID:{jobId}\n任务名称:{jobName}\n执行ID:{runId}\n'''
    msg2 = f'''执行用例数量:{caseTotalNum}\n成功数量:{resultSuccessTotal}|失败数量:{resultFailed}|未知结果数量:{unkownError}\n'''
    msg3 = f'''查看报告概览:{Host}/reportlist/{caseSetId}/\n查看报告详情:{Host}/reportdetail/{runId}/\n'''
    msg =  msg1 + msg2 + msg3
    xiaoding.send_text(msg=msg) #xiaoding.send_text(msg=msg, is_at_all=True)

def sendEmail(jobName,jobId,runId,caseSetId):
    caseTotalNum = runHistory.objects.filter(runId=runId).aggregate(Count('id'))
    caseTotalNum = caseTotalNum['id__count'] 
    resultSuccess = runHistory.objects.filter(runId=runId,validateStatus=1).aggregate(Count('id'))
    resultSuccess = resultSuccess['id__count']
    resultFailed = runHistory.objects.filter(runId=runId,validateStatus=2).aggregate(Count('id'))
    resultFailed = resultFailed['id__count']
    result200 = runHistory.objects.filter(runId=runId,validateStatus=3).aggregate(Count('id'))
    result200 = result200['id__count']
    unkownError = runHistory.objects.filter(runId=runId).exclude(validateStatus__in=[1,2,3]).aggregate(Count('id'))
    unkownError = unkownError['id__count']
    resultSuccessTotal = resultSuccess + result200
    msg1 = f'''[测试结果推送-{resultFailed}失败]\n任务ID:{jobId}\n任务名称:{jobName}\n执行ID:{runId}\n'''
    msg2 = f'''执行用例数量:{caseTotalNum}\n成功数量:{resultSuccessTotal}|失败数量:{resultFailed}|未知结果数量:{unkownError}\n'''
    msg3 = f'''查看报告概览:{Host}/reportlist/{caseSetId}/\n查看报告详情:{Host}/reportdetail/{runId}/\n'''
    
    my = MyEmail()
    my.user =  cf.get("sendnotice", "EmailSendUser")#"zg.yu@ifootstone.com"
    my.passwd = cf.get("sendnotice", "EmailSendUserLoginPwd")
    EmailToList = cf.get("sendnotice", "EmailToList") #获取需要发送邮件的
    my.to_list = json.loads(EmailToList) #ast.literal_eval(EmailToList)#
    my.cc_list = ["", ]
    tag = msg1
    my.tag = tag
    msg =  msg1 + msg2 + msg3
    my.content = msg
    my.send()


