from django.apps import AppConfig


class SendnoticeConfig(AppConfig):
    name = 'sendnotice'
