from django.shortcuts import render
from testcase.models import case,project
from runcase.models import caseSet,runHistory
from runcase.requestMethod import requestGet,requestPost
import time
import json
from django.db.models import Sum,Count,Max,Min,Avg

def reportList(request,id):
    caseSetObj = caseSet.objects.filter(id=id).first()
    runIdDictList = runHistory.objects.filter(caseSetId=id).values("runId").distinct().order_by('-runId') #取出runId并去重、倒序
#     print(runIdDictList)
    
    i = 0
    resDictList = []
    for runIdDict in runIdDictList:
        runIdDict = runIdDictList[i]
#         print(str(runIdDict)+'-------------')
        runId = runIdDict['runId']
#         print(runId)
        caseIdList =  runHistory.objects.filter(runId=runId).first().caseIdList #同 caseIdList = runHistory.objects.filter(runId=runId).values("caseIdList")
#         print(str(caseIdList) + '************')
        caseTotalNum = runHistory.objects.filter(runId=runId).aggregate(Count('id'))
        caseTotalNum = caseTotalNum['id__count'] 
        resultSuccess = runHistory.objects.filter(runId=runId,validateStatus=1).aggregate(Count('id'))
        resultSuccess = resultSuccess['id__count']
        resultFailed = runHistory.objects.filter(runId=runId,validateStatus=2).aggregate(Count('id'))
        resultFailed = resultFailed['id__count']
        result200 = runHistory.objects.filter(runId=runId,validateStatus=3).aggregate(Count('id'))
        result200 = result200['id__count']
        unkownError = runHistory.objects.filter(runId=runId).exclude(validateStatus__in=[1,2,3]).aggregate(Count('id'))
        unkownError = unkownError['id__count']
        avgTime = runHistory.objects.filter(runId=runId,elapsed__isnull=False).aggregate(Avg('elapsed'))
        avgTime = avgTime['elapsed__avg']
        maxTime = runHistory.objects.filter(runId=runId,elapsed__isnull=False).aggregate(Max('elapsed'))
        maxTime = maxTime['elapsed__max']
        minTime = runHistory.objects.filter(runId=runId,elapsed__isnull=False).aggregate(Min('elapsed'))
        minTime = minTime['elapsed__min'] 
#         avgTime = result200['id__count']
        resDict = {"num":str(i+1),"runId":runId,"caseIdList":caseIdList,"caseTotalNum":caseTotalNum,
                   "resultSuccess":resultSuccess,"resultFailed":resultFailed,"result200":result200,"unkownError":unkownError,
                   "avgTime":avgTime,"maxTime":maxTime,"minTime":minTime
                   }
        resDictList.append(resDict)
        i=i+1
#     print(resDictList)
    return render(request, 'reportlist.html',{
                                        "caseSetObj":caseSetObj,
                                        "resDictList":resDictList
                                    
                                                })
    
def reportDetail(request,id):
    runHistoryObj = runHistory.objects.filter(runId=id) #url传的runId
    
    return render(request, 'reportDetail.html',{
                                        "runHistoryObj":runHistoryObj,
                                    
                                                })
    
def reportCaseDetail(request,id):
    runHistoryObj = runHistory.objects.filter(id=id) #url传的runId
    
    return render(request, 'reportcaseDetail.html',{
                                        "runHistoryObj":runHistoryObj,
                                    
                                                })
    
    
    