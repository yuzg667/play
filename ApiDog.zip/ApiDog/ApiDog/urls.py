# -*- coding: utf-8 -*-
"""ApiDog URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from django.views import static as dstatic
from django.conf import settings
from django.views.generic.base import RedirectView
from runcase import views as runcase
from testcase import views as testcase
from reports import views as reports
from schedulejob import views as schedulejob

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', runcase.indexpage),
    path('caselist/', testcase.caseList),
    path('addcase/', testcase.addCase,name="addcaseUrl"),
    path('editcase/<id>/', testcase.editCase,name="editcaseUrl"), #(?P<id>\d+)
    
    path('casesetlist/', runcase.CaseSetList), 
    path('addcaseset/', runcase.addCaseSet,name="addcaseSetUrl"), #(?P<id>\d+)
    path('editcaseset/<id>/', runcase.editCaseSet,name="editcaseSetUrl"), #(?P<id>\d+)

#    path('p1/',runcase.p1),
   path('p2/', runcase.p2),
   
   path('reportlist/<id>/', reports.reportList,name="reportlistUrl"),
   path('reportdetail/<id>/', reports.reportDetail,name="reportdetailUrl"),
   path('reportcasedetail/<id>/', reports.reportCaseDetail,name="reportcasedetailUrl"),
   
   path('schedulejoblist/', schedulejob.schedulejoblist,name="schedulejobUrl"),
#    path('jobp2/', schedulejob.jobp2,name="jobp2Url"),
#    path('addschedulejob/', schedulejob.addschedulejob,name="addschedulejobUrl"),
    
    #关闭debug时使用
    path(r'static/(?P<path>.*)',dstatic.serve,{'document_root':settings.STATIC_ROOT}),
    path(r'media/(?P<path>.*)', dstatic.serve, {'document_root': settings.MEDIA_ROOT}),
    path(r'favicon.ico', RedirectView.as_view(url='http://pic.hellotom.top/media/uploads/images/favicon.ico',permanent=True)),
#     path(r'^static/(?P<path>.*)$',dstatic.serve,{'document_root':settings.STATIC_ROOT}),
#     path(r'^media/(?P<path>.*)$', dstatic.serve, {'document_root': settings.MEDIA_ROOT}),
#     path(r'^favicon.ico$', RedirectView.as_view(url='http://pic.hellotom.top/media/uploads/images/favicon.ico',permanent=True)),
]



if settings.DEBUG:
    from django.conf.urls.static import static
    urlpatterns += static(
        settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG is False:
    from django.conf.urls.static import static
    urlpatterns += static(
        settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(
        settings.STATIC_URL, document_root=settings.STATIC_ROOT)