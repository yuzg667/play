# -*- coding: utf-8 -*-
'''
post请求
Author:yuzg667
https://github.com/yuzg667/
'''
import requests
import json
import re
from testcase.models import case,project
from runcase.models import runHistory
import time
import json
from time import sleep

def resuestPost(caseID,runId,path): 
    try:
        #运行case的ID应该从前端传进来
        caseObj = case.objects.filter(id=caseID).order_by('id').first()
        projectObj = project.objects.filter(id=caseObj.projectId).order_by('id').first()
        baseUrl = projectObj.baseURL
        relyCase = case.objects.filter(id=caseID).order_by('id').first().relyCaseIdList #查询是否有依赖的case，并取出
        url = baseUrl + path #caseObj.path
        data = caseObj.body
        headers = caseObj.headers
        #如果没有默认头信息，使用project的默认请求头
        if (str(headers) !="None") and (headers.isspace() == False) and (len(headers) != 0):
            headers = json.loads(headers.replace("'", "\""))
        else:
            headers = projectObj.defaultHeaders
            headers = json.loads(headers.replace("'", "\""))
        print(url)
        method = caseObj.method
        print("method:" + str(method))
    #     r = requests.post(url,data=data,headers=headers,timeout=10)
        if str(method).upper() =="POST":
            r = requests.post(url,data=data,headers=headers,timeout=10)
            responResult = r.text
            elapsed= str(r.elapsed)
            httpcode=str(r.status_code)
        elif str(method).upper() =="GET":
            r = requests.get(url,params=data,timeout=10)
            responResult = r.text
            elapsed= str(r.elapsed)
            httpcode=str(r.status_code)
        else:
           responResult = "暂不支持的请求方式"
           elapsed= "0:00:00.000000"
           httpcode="-"
#         responResult = r.text
        #把“0:00:00.026268”形式的时间转换为微妙“3603017493”形式
#         elapsed= str(r.elapsed)
#         httpcode=r.status_code
        elapsed = int(elapsed[:-13])*60*60*1000000 + int(elapsed[-12:-10])*60*1000000 + int(elapsed[-9:-7])*1000000 + int(elapsed[-6:])
        runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(response=responResult,
                                                                           url=url,
                                                                           request=data,
                                                                           header=headers,
                                                                           elapsed=elapsed,
                                                                           httpcode=httpcode,
                                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                           ) #请求信息写入表，方便以后画统计图

        print(responResult)
#     responResult = json.loads(responResult) #json.loads会把双引号变为单引号，注意断言时使用r.text

        #断言
        if (str(caseObj.validate) !="None") and (caseObj.validate.isspace() == False) and (len(caseObj.validate) != 0):#判断testcase表数据库的此字段有值
            validate = caseObj.validate
            if  str(validate) in str(responResult):
                print("断言成功" + str(validate))
                runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(validateStatus=1,updateTime=time.strftime("%Y-%m-%d %H:%M:%S"))
            else:
                print("断言失败" + str(validate))
                runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(validateStatus=2,updateTime=time.strftime("%Y-%m-%d %H:%M:%S"))
        elif (str(caseObj.validate) =="None" or  (caseObj.validate.isspace() == True) or (len(caseObj.validate) == 0)) and str(projectObj.defaultValidate) !="None" and (projectObj.defaultValidate.isspace() == False) and (len(projectObj.defaultValidate) != 0):#判断数据库的此字段有值
            validate = projectObj.defaultValidate
            if  str(validate) in str(responResult):
                print("断言成功" + str(validate))
                runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(validateStatus=1,validate=validate,updateTime=time.strftime("%Y-%m-%d %H:%M:%S"))
            else:
                print("断言失败" + str(validate))
                runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(validateStatus=2,validate=validate,updateTime=time.strftime("%Y-%m-%d %H:%M:%S"))
        else:
            print("未设置断言")
            if (httpcode=="200"):
                runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(validateStatus=3,updateTime=time.strftime("%Y-%m-%d %H:%M:%S"))
            elif (httpcode!="200"):
                 runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(validateStatus=2,updateTime=time.strftime("%Y-%m-%d %H:%M:%S"))
    
        #提取值
        extract = caseObj.extract #"plaintext":"(.*?)"
        print('提取正则公式' + str(extract))
        if str(extract) !="None" and str(extract).isspace() == False: #判断数据库的此字段有值，且不为空格
            pattern = re.compile(str(extract))
            res = re.findall(pattern,str(responResult))
            if len(res)>0:
                extractValue = str(res[0])
                runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(extract=extract,
                                                                                   extractValue=extractValue,
                                                                                   updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                                   )
#                 print('写入成功---')
            else:
                extractValue = '提取值为空'
    #             pass
                print("提取值为空")
            print(extractValue)
        else:
            print("未设置提取值")
        
    except Exception as e:
        responResult = e
        runHistory.objects.filter(runId=runId,CurrentCaseId=caseID).update(response=responResult,
                                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                           ) #请求信息写入表，方便以后画统计图
        print(responResult)    
    
def runRequestPost(submitCaseidlist,caseSetId):
#     global runId
    runId = time.strftime('%Y%m%d%H%M%S') #每次执行，为执行的用例集，生成一个共同唯一编号
#     submitCaseidlist = "[1,2,3,4]" #实际需要前端传入
    print(runId)
    caseIdString2List = json.loads(submitCaseidlist) #string转换为list
    
    #for循环 取出must执行的case，组成新的list （意在must=1的用例只执行一次）
    for caseID in caseIdString2List: 
        caseObj = case.objects.filter(id=caseID).order_by('id').first()
        path = caseObj.path
        if caseObj.must==1:
            p = runHistory(runId=runId, #把要执行case的相关数据入数据库
                           caseSetId=caseSetId,
                           caseIdList = submitCaseidlist,
                           CurrentCaseId=caseID,
                           method=caseObj.method,
                           projectName = caseObj.projectName,
                           projectId = caseObj.projectId,
                           caseName = caseObj.caseName
                            )
            p.save()
            resuestPost(caseID,runId,path)
            caseIdString2List.remove(caseID)

    for caseID in caseIdString2List:
        caseObj = case.objects.filter(id=caseID).order_by('id').first()
        path = caseObj.path
        #先判断是否有依赖的case，如果有，先执行被依赖的case
        print("caseID:" + str(caseID))
        relyCaseIdList = caseObj.relyCaseIdList #json.loads(relyCase.relyCaseIdList)
        
        runHistoryObj = runHistory.objects.filter(runId=runId,CurrentCaseId=relyCaseIdList) #查询依赖case是否已经执行
#         print(str(runHistoryObj)+'999999999999999')
        # 判断是否有依赖的case
        if ( int(relyCaseIdList)>0  ): #有依赖case执行这段，###这个条件暂无使用
            print(f"@@@Case {relyCaseIdList} start. @@@")
            #把要执行case的相关数据入数据库
            #for relyCaseId in relyCaseIdList:   #依赖case暂无使用，下边这行暂无使用
            relyPath = case.objects.filter(id=relyCaseIdList).order_by('id').first().path.format(token=runHistory.objects.filter(runId=runId,CurrentCaseId=1).order_by('id').first().extractValue,time=time.time())
            p = runHistory(runId=runId, #把要执行case的相关数据入数据库
                   caseSetId=caseSetId,
                   caseIdList = submitCaseidlist,
                   CurrentCaseId=relyCaseIdList,
                   method=caseObj.method,
                   remark='relyCase',
                   projectName = caseObj.projectName,
                   projectId = caseObj.projectId,
                   caseName = caseObj.caseName
                    )
            p.save()
            resuestPost(relyCaseIdList,runId,relyPath)
            print(f"@@@Case {relyCaseIdList} finished. @@@ \n")
            
            #再执行非依赖的case    
            print(f"***Case {caseID} start. ***")
            path = caseObj.path.format(token=runHistory.objects.filter(runId=runId,CurrentCaseId=1).order_by('id').first().extractValue,time=time.time())

            p = runHistory(runId=runId, #把要执行case的相关数据入数据库
                       caseSetId=caseSetId,
                       caseIdList = submitCaseidlist,
                       CurrentCaseId=caseID,
                       method=caseObj.method,
                       projectName = caseObj.projectName,
                       projectId = caseObj.projectId,
                       caseName = caseObj.caseName
                        )
            p.save()
            resuestPost(caseID,runId,path)
            print(f"***Case {caseID} finished. *** \n")

        else: #没有依赖case执行这段
            print(f"###2Case {caseID} start. ###")
            #如果有must的case，需要执行修改下边这一行的代码
#             path = caseObj.path.format(token=runHistory.objects.filter(runId=runId,CurrentCaseId=1).order_by('id').first().extractValue,time=time.time())
            path = caseObj.path
            p = runHistory(runId=runId, #把要执行case的相关数据入数据库
                           caseSetId=caseSetId,
                           caseIdList = submitCaseidlist,
                           CurrentCaseId=caseID,
                           method=caseObj.method,
                           projectName = caseObj.projectName,
                           projectId = caseObj.projectId,
                           caseName = caseObj.caseName
                
                            )
            p.save()
            resuestPost(caseID,runId,path)
            print(f"###2Case {caseID} finished. ### \n")
            
    return runId 

