from django.shortcuts import render
from testcase.models import case,project
from runcase.models import caseSet,runHistory
from runcase.requestMethod import requestGet,requestPost
import time
import json


def indexpage(request):
#     requestPost.runRequestPost()
    
    return render(request, 'index.html',{
                                    
                                                })
def CaseSetList(request):
    caseSetObj = caseSet.objects.exclude(deleted=1).order_by('-id')
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    projectName = "所有项目"
    if request.POST:
        if ('Inquiry') in request.POST: #py3 
            form_commitProjectId = request.POST['projectId'].strip()
            if int(form_commitProjectId)>0:
                caseSetObj = caseSet.objects.filter(projectId=form_commitProjectId,deleted=0).order_by('-id')
                projectName = project.objects.filter(id=form_commitProjectId).first().projectName
            else:
                caseSetObj = caseSet.objects.exclude(deleted=1).order_by('-id')
                projectName = "所有项目"

        if ('delCaseSet') in request.POST: #py3 
            form_commit = request.POST['caseSetId'].strip()
            if form_commit:
                caseSet.objects.filter(id=form_commit).update(deleted=1)
                
#         #同步做法：点击运行按钮，直接执行caseSet
#         if ('runCaseSet') in request.POST: #py3 
#             form_commit = request.POST['caseIdList'].strip()
#             caseSetId = request.POST['caseSetId'].strip()
#             if form_commit and caseSetId:
#                 submitCaseidlist = form_commit
#                 requestPost.runRequestPost(submitCaseidlist,caseSetId)
#                 oldRunNum = caseSet.objects.get(id=int(caseSetId)).runNum
#                 newRunNum = oldRunNum + 1
#                 caseSet.objects.filter(id=caseSetId).update(runNum=newRunNum,
#                                                            updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
#                                                                                )
        #异步做法：点击运行按钮，更新表caseSet.status=1，等待apscheduler定时任务执行
        if ('runCaseSet') in request.POST: #py3 
            caseSetId = request.POST['caseSetId'].strip()
            if caseSetId:
                caseSet.objects.filter(id=caseSetId).update(status=1,
                                                           updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                               )
    
    return render(request, 'casesetlist.html',{"caseSetObj":caseSetObj,
                                         "projectObj":projectObj,
                                         "projectName":projectName,

                                                })

def addCaseSet(request):
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    qcaseSetList = ''
    qcaseSetname = ''
    msg = ''

    if request.POST:
        #获取前端传进来的值
        projectId =  request.POST['projectId']
        print(projectId)
        qcaseSetname =  request.POST['qcaseSetname']
        qcaseSetListPost =  request.POST['qcaseSetList']

        if (projectId !='' and qcaseSetname !='' and qcaseSetListPost !=''): #判断必填字段不为空
            projectIdObj = project.objects.filter(id=projectId).first()
            #过滤不符合所属项目的case,组成新的qcaseSetList
            qcaseSetListPost = json.loads(qcaseSetListPost)
            qcaseSetList = []
            for i in qcaseSetListPost:
                if int(projectId) == int(case.objects.filter(id=i).first().projectId):
                    qcaseSetList.append(i)
        
            p = caseSet(
                       projectId =  projectId,
                        caseSetName = qcaseSetname,
                        projectName=projectIdObj.projectName,
                        caseIdList = qcaseSetList,
                        updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                               )
            p.save()
        else:
            msg = '检查填写是否完善'

    return render(request, 'add_caseset.html',{
                                            "projectObj":projectObj,
                                            "msg":msg,

                                                })

def editCaseSet(request,id):
    #用例列表进入编辑页面
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    editCaseObj = caseSet.objects.get(id=int(id))
    #编辑保存用例
    ##给默认值
    qcaseSetList = ''
    qcaseSetname = ''
    projectId =  ''
    msg = ''
 
    if request.POST:
        #获取前端传进来的值
        projectId =  request.POST['projectId']
        qcaseSetname =  request.POST['qcaseSetname']
        qcaseSetListPost =  request.POST['qcaseSetList']
        if (projectId !='' and qcaseSetname !='' and qcaseSetListPost !=''): #判断必填字段不为空
            projectIdObj = project.objects.filter(id=projectId).first()
            #过滤不符合所属项目的case,组成新的qcaseSetList
            qcaseSetListPost = json.loads(qcaseSetListPost)
            qcaseSetList = []
            for i in qcaseSetListPost:
                if int(projectId) == int(case.objects.filter(id=i).first().projectId):
                    qcaseSetList.append(i)
            caseSet.objects.filter(id=id).update(projectId =  projectId,
                    caseSetName = qcaseSetname,
                    projectName=projectIdObj.projectName,
                    caseIdList = qcaseSetList,
                    updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                )
            editCaseObj = caseSet.objects.filter(id=id).first() #更新后，重新为editCaseObj赋数据库中的最新值
            msg = '更新成功'
        elif (projectId !='' or qcaseSetname !='' or qcaseSetList !=''): #判断必填字段不为空
            msg = '检查填写是否完善'
        else:
            msg = '检查填写是否完善'
    
    return render(request, 'edit_caseset.html',{
                                            'editCaseObj':editCaseObj,
                                            'projectObj':projectObj,
                                            'msg':msg,

                                                })

##https://www.cnblogs.com/hedeyong/p/7717840.html
def p2(request):
    caseObj = case.objects.exclude(deleted=1).order_by('id')
    projectObj = project.objects.exclude(deleted=1).order_by('-id') #为/addcase/页面获取项目列表
    caseidlist = ''
    form_commitProjectId = 0
    projectName = "所有项目"
    if request.method == "GET":
        return render(request,"p2.html",{
                            "caseid":caseidlist,
                                         "caseObj":caseObj,
                                         "projectObj":projectObj,
                                         "form_commitProjectId":form_commitProjectId,
                                         "projectName":projectName
                         })
    
    elif request.POST:
#         city =request.POST.get("city")
        #添加用例
        if ('addcase2set') in request.POST: #py3 
            check_box_list = request.POST.getlist("check_box_list")
            check_box_list_str = str(check_box_list).replace(' ', '').replace("'", "\"").replace("\"", "")#去除空格、引号换双引号、去掉双引号
#             print(check_box_list_str)
#             check_box_list = json.loads(check_box_list_str)
            caseidlist = check_box_list_str
            print(caseidlist)
        if ('Inquiry') in request.POST: #py3 
            form_commitProjectId = request.POST['projectId'].strip()
            templateHtml = 'caselist.html'
            if int(form_commitProjectId)>0:
                caseObj = case.objects.filter(projectId=form_commitProjectId,deleted=0).order_by('id')
                projectName = project.objects.filter(id=form_commitProjectId).first().projectName
            else:
                caseObj = case.objects.exclude(deleted=1).order_by('id')
                projectName = "所有项目"
        return render(request,"p2.html",{"caseid":caseidlist,
                                         "caseObj":caseObj,
                                         "projectObj":projectObj,
                                         "form_commitProjectId":form_commitProjectId,
                                         "projectName":projectName
                                         })
    

    
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore, register_events, register_job
##https://note.youdao.com/web/#/file/recent/note/wcp1566782277036579/  详解django-apscheduler的使用方法 - 掘金
#开启定时工作
try:
    # 实例化调度器
    scheduler = BackgroundScheduler()
    # 调度器使用DjangoJobStore()
    scheduler.add_jobstore(DjangoJobStore(), "default")
    # 设置定时任务，选择方式为interval，时间间隔为10s
    # 另一种方式为每天固定时间执行任务，对应代码为：
    # @register_job(scheduler, 'cron', day_of_week='mon-fri', hour='9', minute='30', second='10',id='task_time')
    @register_job(scheduler,"interval", seconds=5)
    def my_job():
        # 这里写你要执行的任务
        print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("\n定时任务检查："+ str(time.strftime("%Y-%m-%d %H:%M:%S")))
        caseSetObj = caseSet.objects.filter(status=1).order_by('updateTime').first() #取出status=1的待执行的caseSet
        print("取到的caseSet:" + str(caseSetObj))
        if (str(caseSetObj) !="None") and (str(caseSetObj).isspace() == False) and (len(str(caseSetObj)) != 0):
            caseSetId = caseSetObj.id
            submitCaseidlist = caseSetObj.caseIdList
            #状态更新为2运行中
            caseSet.objects.filter(id=caseSetId).update(status=2,
                                                       updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                           )
            #执行caseSet
            requestPost.runRequestPost(submitCaseidlist,caseSetId)
            oldRunNum = caseSet.objects.get(id=int(caseSetId)).runNum
            newRunNum = oldRunNum + 1
            #状态更新为3运行结束
            caseSet.objects.filter(id=caseSetId).update(status=3,
                                                        runNum=newRunNum,
                                                       updateTime=time.strftime("%Y-%m-%d %H:%M:%S")
                                                                           )
        else:
            print("暂无需要执行的caseSet")
    register_events(scheduler)
    scheduler.start()
     
except Exception as e:
    print(e)
    # 有错误就停止定时器
    scheduler.shutdown()    

