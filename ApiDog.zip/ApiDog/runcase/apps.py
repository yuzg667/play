from django.apps import AppConfig


class RuncaseConfig(AppConfig):
    name = 'runcase'
